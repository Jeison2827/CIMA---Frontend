import React from 'react';

const WorkerDashboard = () => {
  return (
    <div>
      <h2>Panel de cliente</h2>
      <ul>
        <li>Bien Venido</li>
      </ul>
    </div>
  );
};

export default WorkerDashboard;
